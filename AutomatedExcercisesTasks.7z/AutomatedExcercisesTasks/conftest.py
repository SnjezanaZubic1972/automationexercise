import pytest
import time
from playwright.sync_api import sync_playwright
from pages.home_page import HomePage
from pages.login_page import LoginPage
from pages.registration_page import RegistrationPage

@pytest.fixture(scope="function")
def setup():
    """Provides a Playwright page object for each test."""
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)  # set True for CI
        context = browser.new_context()
        page = context.new_page()



 # Umesto blokiranja mreže, ubrizgavamo CSS koji krije reklame i banere
        page.add_init_script("""
            const style = document.createElement('style');
            style.innerHTML = `
                .adsbygoogle, #google_esf, .google-ad, #slider-carousel {
                    display: none !important;
                    visibility: hidden !important;
                    pointer-events: none !important;
                }
            `;
            document.head.appendChild(style);
        """)




        yield page # Provide both page and context to tests for cleanup
        context.close()

        browser.close()

@pytest.fixture(scope="function")
def registered_user(setup):
    """Registers a new user and returns its credentials for login tests."""
    page = setup
    page.goto("https://www.automationexercise.com")

    # Navigate to Signup/Login
    home = HomePage(page)
    home.go_to_login()

    # Generate unique email
    login = LoginPage(page)
    email = f"test{int(time.time())}@example.com"
    login.signup("Test User", email)

    # Fill registration form
    registration = RegistrationPage(page)
    user_data = {
        "password": "Password123",
        "day": "10",
        "month": "5",
        "year": "1990",
        "first_name": "Test",
        "last_name": "User",
        "address": "123 Test Street",
        "country": "Canada",
        "state": "Ontario",
        "city": "Toronto",
        "zipcode": "M1A1A1",
        "mobile": "+1234567890"
    }
    registration.fill_form(user_data)
    registration.submit()
    registration.verify_success()

    # Return credentials for login/logout tests
    return {"email": email, "password": user_data["password"]}




def clear_ui_barriers(page):
    # Force-uj sakrivanje carousela i svih potencijalnih overlay-a
    page.add_style_tag(content="""
        #slider-carousel, .ns-inv8z-e-1, .adsbygoogle,google_esf, iframe { 
            display: none !important; 
            pointer-events: none !important; 
        }
        header { z-index: 9999 !important; } /* Gurni meni u prvi plan */
    """)
