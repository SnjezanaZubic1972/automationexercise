from turtle import home
from matplotlib.style import context
import pytest
from conftest import clear_ui_barriers
from pages.home_page import HomePage
from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage
from pages.logout_page import LogoutPage

#@pytest.mark.smoke
def test_login_logout(setup, registered_user):
    page = setup
    page.context.clear_cookies()
    page.reload()

   
    page.goto("https://www.automationexercise.com")


    home = HomePage(page)
    home.go_to_login()

    login = LoginPage(page)
    login.login(registered_user["email"], registered_user["password"])

    dashboard = DashboardPage(page)
    assert dashboard.is_logged_in()
    

    dashboard.logouting()

    assert dashboard.is_logged_out()

    assert page.locator("a:has-text(' Signup / Login')").is_visible()

