from turtle import home
import pytest
from pages.home_page import HomePage
from pages.product_page import ProductPage
from pages.cart_page import CartPage

def test_add_to_cart(setup):
    page = setup
    page.goto("https://www.automationexercise.com")
   
   
    page.reload(wait_until="domcontentloaded") 
       # Step 1: Navigate to Products
    home = HomePage(page)
    page.reload(wait_until="domcontentloaded")
    home.go_to_products()
    page.reload(wait_until="domcontentloaded")
    

    # Step 2: Add first product to cart
    product = ProductPage(page)
    product.add_first_product_to_cart()
    product.go_to_cart()

    # Step 3: Proceed to cart
    cart = CartPage(page)
    assert cart.is_product_in_cart()

    cart.proceed_to_checkout()

    # Step 4: Verify product is in cart
    assert page.is_visible("td.cart_description"), "Product not found in cart"
    assert page.is_visible("td.cart_price"), "Product price not visible"