from playwright.sync_api import sync_playwright, expect
import time

def robust_logout_test():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()

        # Step 1: Login
        page.goto("https://automationexercise.com/login")
        page.fill('input[data-qa="login-email"]', "snjezana.zubic1972@gmail.com")
        page.fill('input[data-qa="login-password"]', "Password123")
        page.click('button[data-qa="login-button"]')
        expect(page.get_by_text("Logged in as")).to_be_visible(timeout=5000)

        # Step 2: Click Logout and wait for network response
        with page.expect_response(lambda response: "/logout" in response.url and response.status == 200) as logout_response:
            page.click('a[href="/logout"]')
        response = logout_response.value
        assert response.ok, "Logout API did not return 200 OK"

        # Step 3: Assert URL redirection
        expect(page).to_have_url("https://automationexercise.com/login", timeout=5000)

        # Step 4: Wait for banners/overlays to disappear
        try:
            page.wait_for_selector('.banner, .overlay', state='hidden', timeout=3000)
        except:
            pass  # Ignore if not present

        # Step 5: Poll for "Signup / Login" link
        def is_signup_login_visible():
            return page.locator('header a[href="/login"]').is_visible()
        expect.poll(is_signup_login_visible, timeout=10000).to_be_truthy()

        # Step 6: Assert absence of "Logged in as"
        expect(page.get_by_text("Logged in as")).to_be_hidden(timeout=5000)

        # Step 7: Validate session cookies are cleared
        cookies = context.cookies()
        auth_cookies = [cookie for cookie in cookies if "session" in cookie["name"]]
        assert not auth_cookies, "Session cookies should be cleared after logout"

        # Step 8: Attempt to access a protected page
        page.goto("https://automationexercise.com/account")
        expect(page).to_have_url("https://automationexercise.com/login", timeout=5000)

        print("Logout test passed reliably.")

        browser.close()

if __name__ == "__main__":
    robust_logout_test()