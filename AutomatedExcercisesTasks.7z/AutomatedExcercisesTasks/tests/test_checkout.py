import pytest
from pages.home_page import HomePage
from pages.product_page import ProductPage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage

def test_checkout(setup):
    page = setup
    page.goto("https://www.automationexercise.com")

    # Step 1: Navigate to Products
    home = HomePage(page)
    home.go_to_products()

    # Step 2: Add product to cart
    product = ProductPage(page)
    product.add_first_product_to_cart()

    # Step 3: Proceed to checkout
    cart = CartPage(page)
    cart.proceed_to_checkout()

    # Step 4: Place order
    checkout = CheckoutPage(page)
    checkout.place_order()

    # Step 5: Enter payment details
    card_data = {
        "name": "Test User",
        "number": "4111111111111111",  # test Visa number
        "cvc": "123",
        "month": "12",
        "year": "2026"
    }
    checkout.enter_payment_details(card_data)

    # Step 6: Verify order success
    assert page.is_visible("div.alert-success"), "Order success message not visible"