def test_user_registration(setup):
    page = setup
    page.goto("https://www.automationexercise.com")

    from pages.home_page import HomePage
    from pages.login_page import LoginPage
    from pages.registration_page import RegistrationPage
    from pages.dashboard_page import DashboardPage

    home = HomePage(page)
    home.go_to_login()

    login = LoginPage(page)
    import time
    email = f"test{int(time.time())}@example.com"
    login.signup("Test User", email)

    registration = RegistrationPage(page)
    user_data = {
        "password": "Password123",
        "day": "10",
        "month": "5",
        "year": "1990",
        "first_name": "Test",
        "last_name": "User",
        "address": "123 Test Street",
        "country": "Canada",
        "state": "Ontario",
        "city": "Toronto",
        "zipcode": "M1A1A1",
        "mobile": "+1234567890"
    }
    registration.fill_form(user_data)
    registration.submit()
    registration.verify_success()

    dashboard = DashboardPage(page)
    assert dashboard.is_logged_in()