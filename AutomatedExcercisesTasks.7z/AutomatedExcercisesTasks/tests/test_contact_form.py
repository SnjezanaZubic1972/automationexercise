import pytest
from pages.home_page import HomePage
from pages.contact_page import ContactPage

def test_contact_form(setup):
    page = setup
    page.goto("https://www.automationexercise.com")

    # Step 1: Navigate to Contact page
    home = HomePage(page)
    home.go_to_contact()

    # Step 2: Fill and submit contact form
    contact = ContactPage(page)
    contact.submit_contact_form(
        name="Test User",
        email="testuser@example.com",
        subject="Automation Test",
        message="This is a test message sent via Playwright automation."
    )

    # Step 3: Verify success message
    contact.verify_success()