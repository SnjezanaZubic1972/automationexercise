from playwright.sync_api import TimeoutError, expect

from conftest import clear_ui_barriers

class DashboardPage:
    def __init__(self, page):
        self.page = page
        #self.logout_link = "a:has-text('Logout')"
        self.logout_link = "header a[href='/logout'], a[href='/logout']"
        self.login_link = "header a[href='/login']"


    def is_logged_in(self):
        return self.page.is_visible(self.logout_link)

    def logout(self):
        
        # Wait for logout link to be visible
        
        self.page.wait_for_selector(self.logout_link, state="visible", timeout=10000)


        # Click logout and wait for navigation back to homepage
        with self.page.expect_navigation(url="https://www.automationexercise.com/"):
             self.page.locator(self.logout_link).click(force=True)




    def logouting(self):
        # Try clicking logout link if visible
    
        if self.page.locator(self.logout_link).is_visible():
            # Start waiting for network/URL/header signals after click
            try:
                with self.page.expect_navigation(timeout=5000):
                    clear_ui_barriers(self.page)
                    loc = self.page.locator(self.logout_link)
                    loc.scroll_into_view_if_needed()
                    loc.dblclick(force=True)
            except TimeoutError:
                # If no network response observed, still attempt a visible double-click
                clear_ui_barriers(self.page)
                loc = self.page.locator(self.logout_link)
                loc.scroll_into_view_if_needed()
                loc.dblclick(force=True)
        # Wait for any of the reliable signals
        ok = self._wait_for_logout_signals(timeout=10000)

        # If signals did not confirm logout, force cleanup
        if not ok:
            self.page.context.clear_cookies()
            self.page.evaluate("() => { try { localStorage.clear(); sessionStorage.clear(); } catch(e){} }")
            self.page.goto("https://www.automationexercise.com", wait_until="domcontentloaded")


    def is_logged_out(self):
        return self.page.is_visible("a[href='/login']")



    def _wait_for_logout_signals(self, timeout=10000):
        try:
            self.page.wait_for_url("**/login", timeout=2000)
            return True
        except TimeoutError:
            pass
        try:
            self.page.wait_for_url("https://www.automationexercise.com/", timeout=2000)
            return True
        except TimeoutError:
            pass

        # 2) Wait for header login link presence (ignores mid-page content)
        try:
            self.page.wait_for_function(
                "selector => !!document.querySelector(selector)",
                arg=self.login_link,
                timeout=3000
            )
            return True
        except TimeoutError:
            return False

   