class LoginPage:
    def __init__(self, page):
        self.page = page
        self.name_input = "input[name='name']"
        self.email_input = "input[data-qa='signup-email']"
        self.signup_button = "button[data-qa='signup-button']"
        self.login_email = "input[data-qa='login-email']"
        self.login_password = "input[data-qa='login-password']"
        self.login_button = "button[data-qa='login-button']"

    def signup(self, name, email):
        self.page.fill(self.name_input, name)
        self.page.fill(self.email_input, email)
        self.page.click(self.signup_button)

    def login(self, email, password):
        self.page.fill(self.login_email, email)
        self.page.fill(self.login_password, password)
        self.page.click(self.login_button)