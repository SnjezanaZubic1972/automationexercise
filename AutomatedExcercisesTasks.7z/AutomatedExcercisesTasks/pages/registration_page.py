class RegistrationPage:
    def __init__(self, page):
        self.page = page
        self.gender_male = "#id_gender1"
        self.password = "#password"
        self.days = "#days"
        self.months = "#months"
        self.years = "#years"
        self.first_name = "#first_name"
        self.last_name = "#last_name"
        self.address = "#address1"
        self.country = "#country"
        self.state = "#state"
        self.city = "#city"
        self.zipcode = "#zipcode"
        self.mobile = "#mobile_number"
        self.create_account_btn = "button[data-qa='create-account']"
        self.success_message = "h2[data-qa='account-created']"
        self.continue_btn = "a[data-qa='continue-button']"

    def fill_form(self, user):
        self.page.check(self.gender_male)
        self.page.fill(self.password, user["password"])
        self.page.select_option(self.days, user["day"])
        self.page.select_option(self.months, user["month"])
        self.page.select_option(self.years, user["year"])
        self.page.fill(self.first_name, user["first_name"])
        self.page.fill(self.last_name, user["last_name"])
        self.page.fill(self.address, user["address"])
        self.page.select_option(self.country, user["country"])
        self.page.fill(self.state, user["state"])
        self.page.fill(self.city, user["city"])
        self.page.fill(self.zipcode, user["zipcode"])
        self.page.fill(self.mobile, user["mobile"])

    def submit(self):
        self.page.click(self.create_account_btn)

    def verify_success(self):
        assert self.page.is_visible(self.success_message)
        assert self.page.inner_text(self.success_message) == "ACCOUNT CREATED!"
        self.page.click(self.continue_btn)