class ContactPage:
    def __init__(self, page):
        self.page = page
        self.name_input = "input[name='name']"
        self.email_input = "input[name='email']"
        self.subject_input = "input[name='subject']"
        self.message_input = "textarea[name='message']"
        self.submit_btn = "input[name='submit']"
        self.success_msg = "div.status.alert.alert-success"

    def submit_contact_form(self, name, email, subject, message):
        self.page.fill(self.name_input, name)
        self.page.fill(self.email_input, email)
        self.page.fill(self.subject_input, subject)
        self.page.fill(self.message_input, message)
        self.page.click(self.submit_btn)

    def verify_success(self):
        assert self.page.is_visible(self.success_msg)