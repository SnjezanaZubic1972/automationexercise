class HomePage:
    def __init__(self, page):
        self.page = page
        self.signup_login_link = "a[href='/login']"
        self.products_link = "a[href='/products']"
        self.contact_link = "a[href='/contact_us']"
        self.logout_link = "a[href='/logout']"


    def go_to_login(self):
        self.page.wait_for_selector(self.signup_login_link, state="visible", timeout=15000)
    
        self.page.locator(self.signup_login_link).click()

    def go_to_products(self):
        self.page.click(self.products_link)

    def go_to_contact(self):
        self.page.click(self.contact_link)


    def logout(self):
        self.page.locator(self.logout_link).click(force=True)

    def is_logged_out(self):
        return self.page.is_visible("a[href='/login']")