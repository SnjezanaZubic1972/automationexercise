class CheckoutPage:
    def __init__(self, page):
        self.page = page
        self.place_order_btn = "a[href='/payment']"
        self.name_on_card = "input[name='name_on_card']"
        self.card_number = "input[name='card_number']"
        self.cvc = "input[name='cvc']"
        self.expiry_month = "input[name='expiry_month']"
        self.expiry_year = "input[name='expiry_year']"
        self.pay_btn = "button[data-qa='pay-button']"

    def place_order(self):
        self.page.click(self.place_order_btn)

    def enter_payment_details(self, card):
        self.page.fill(self.name_on_card, card["name"])
        self.page.fill(self.card_number, card["number"])
        self.page.fill(self.cvc, card["cvc"])
        self.page.fill(self.expiry_month, card["month"])
        self.page.fill(self.expiry_year, card["year"])
        self.page.click(self.pay_btn)