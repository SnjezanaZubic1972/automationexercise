# pages/product_page.py
class ProductPage:
    def __init__(self, page):
        self.page = page
        # Example selector: first product's "Add to cart" button
        self.first_product_add_button = "(//a[@data-product-id])[1]"
        self.cart_link = "a[href='/view_cart']"

    def add_first_product_to_cart(self):
        # Hover over product card to reveal button
        self.page.locator(".features_items .product-image-wrapper").first.hover()
        # Click the add-to-cart button
        self.page.locator(self.first_product_add_button).click()

    def go_to_cart(self, use_modal=True):
        #if use_modal:
        # Wait for modal and click "View Cart"
            self.page.wait_for_selector("#cartModal", state="visible", timeout=10000)
            self.page.locator("#cartModal a[href='/view_cart']").click()
        #else:
        # Click navbar Cart link
            #self.page.get_by_role("link", name=" Cart").click()


        