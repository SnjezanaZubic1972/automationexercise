class CartPage:
    def __init__(self, page):
        self.page = page
        self.checkout_btn = "a[class='btn btn-default check_out']"
        self.cart_table = "#cart_info_table"

    def is_product_in_cart(self):
        return self.page.locator(self.cart_table).is_visible()

    def proceed_to_checkout(self):
        self.page.click(self.checkout_btn)