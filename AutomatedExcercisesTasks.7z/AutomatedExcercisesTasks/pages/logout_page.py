# pages/logout_page.py

class LogoutPage:
    def __init__(self, page):
        self.page = page
        # Stable selector for logout link
        self.logout_link = "a[href='/logout']"
        # After logout, login link should be visible again
        self.login_link = "a[href='/login']"

    def logout(self):
        # Click logout and wait for navigation back to homepage
        self.page.locator(self.logout_link).click(force=True)
        self.page.wait_for_url("https://www.automationexercise.com/")

    def is_logged_out(self):
        # Verify that the login link is visible again
        return self.page.locator(self.login_link).is_visible()
    



    